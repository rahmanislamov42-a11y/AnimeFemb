package com.animecompanion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF211B35)
private val Purple = Color(0xFF8065D8)
private val Lavender = Color(0xFFF0EBFF)
private val Background = Color(0xFFF8F6FC)
private val Muted = Color(0xFF777184)

data class Companion(
    val name: String,
    val role: String,
    val emoji: String,
    val description: String,
    val greeting: String,
    val color: Color
)

private val companions = listOf(
    Companion("Анфалт", "Фембой", "🧸", "Спокойный, доброжелательный, любит игры и музыку.", "Привет! Рад знакомству. О чём поговорим?", Color(0xFFE5E0FF)),
    Companion("Умалат", "Мальчик-кошечка", "🐱", "Энергичный шутник, которому нравятся загадки и приключения.", "Мяу! Привет! Чем займёмся сегодня?", Color(0xFFFFE7F0)),
    Companion("Сеймур", "Аниме-девушка", "🌙", "Рассудительная помощница, любит книги и новые знания.", "Привет! Могу помочь с идеями или учёбой.", Color(0xFFE3EEFF)),
    Companion("Лиора", "Аниме-девушка", "⭐", "Любознательная мечтательница, любит творчество и фантастику.", "Хэй! Давай придумаем что-нибудь интересное!", Color(0xFFFFF0D9))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AnimeCompanionApp() }
    }
}

@Composable
fun AnimeCompanionApp() {
    var selected by remember { mutableStateOf(companions[0]) }
    var page by remember { mutableStateOf("Персонажи") }
    var outfit by remember { mutableStateOf("Повседневный образ") }
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Purple,
            secondary = Color(0xFFB18BEA),
            background = Background,
            surface = Color.White,
            onBackground = Ink,
            onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Персонажи", "Чат", "Гардероб", "Настройки").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Персонажи" -> Icons.Default.Groups
                                        "Чат" -> Icons.Default.Chat
                                        "Гардероб" -> Icons.Default.Checkroom
                                        else -> Icons.Default.Settings
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when (page) {
                    "Персонажи" -> CharacterPage(selected) { selected = it; page = "Чат" }
                    "Чат" -> ChatPage(selected)
                    "Гардероб" -> WardrobePage(selected, outfit) { outfit = it }
                    else -> SettingsPage()
                }
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text("ANIME COMPANION", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(5.dp))
        Text(title, color = Ink, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 13.sp)
    }
}

@Composable
fun CharacterPage(selected: Companion, onSelect: (Companion) -> Unit) {
    Header("Твои персонажи", "Выбери помощника для общения")
    LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(companions) { character ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onSelect(character) },
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(76.dp).background(character.color, RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
                        Text(character.emoji, fontSize = 37.sp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(character.name, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Text(character.role, color = Purple, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text(character.description, color = Muted, fontSize = 12.sp, lineHeight = 16.sp)
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = "Выбрать", tint = Purple)
                }
            }
        }
        item {
            Text("Сейчас выбран: ${selected.name}", color = Muted, modifier = Modifier.padding(8.dp), fontSize = 12.sp)
        }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)

@Composable
fun ChatPage(character: Companion) {
    var input by remember(character.name) { mutableStateOf("") }
    var messages by remember(character.name) { mutableStateOf(listOf(ChatMessage(character.greeting, false))) }
    Header("Чат с ${character.name}", "Твой виртуальный помощник")
    LazyColumn(
        modifier = Modifier.weight(1f).fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(messages) { message ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
                Surface(
                    color = if (message.fromUser) Lavender else Color.White,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.widthIn(max = 300.dp)
                ) {
                    Text(message.text, Modifier.padding(13.dp), color = Ink, fontSize = 14.sp)
                }
            }
        }
    }
    Row(Modifier.fillMaxWidth().background(Color.White).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            modifier = Modifier.weight(1f),
            placeholder = { Text("Напиши сообщение…") },
            shape = RoundedCornerShape(18.dp),
            maxLines = 3
        )
        Spacer(Modifier.width(8.dp))
        IconButton(onClick = {
            val text = input.trim()
            if (text.isNotEmpty()) {
                val answer = when {
                    text.contains("привет", true) -> "Привет! Как проходит твой день?"
                    text.contains("помоги", true) -> "Конечно! Расскажи, с чем именно нужна помощь."
                    text.contains("уч", true) -> "Давай разберём тему по шагам. Что сейчас изучаешь?"
                    text.contains("как дела", true) -> "Всё отлично! А как у тебя дела?"
                    else -> "Интересно! Расскажи об этом немного подробнее — я постараюсь помочь."
                }
                messages = messages + ChatMessage(text, true) + ChatMessage(answer, false)
                input = ""
            }
        }) {
            Icon(Icons.Default.Send, contentDescription = "Отправить", tint = Purple)
        }
    }
}

@Composable
fun WardrobePage(character: Companion, outfit: String, onOutfit: (String) -> Unit) {
    Header("Гардероб", "Выбери образ для ${character.name}")
    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(180.dp).background(character.color, RoundedCornerShape(36.dp)), contentAlignment = Alignment.Center) {
            Text(character.emoji, fontSize = 90.sp)
        }
        Spacer(Modifier.height(12.dp))
        Text(character.name, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Текущий образ: $outfit", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(22.dp))
        listOf("Повседневный образ", "Уютный свитер", "Уличный стиль", "Праздничный наряд").forEach { choice ->
            OutlinedButton(
                onClick = { onOutfit(choice) },
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Purple)
            ) { Text(choice) }
        }
        Text("Пока это выбор названия образа. Иллюстрации одежды добавим следующим этапом.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun SettingsPage() {
    Header("Настройки", "Настрой приложение под себя")
    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Text("Anime Companion", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Версия 1.0 — демонстрационная сборка", color = Muted, fontSize = 13.sp)
            }
        }
        Text("Чат в этой первой версии отвечает локальными демонстрационными фразами. Подключение настоящего ИИ и сохранение истории добавим отдельно.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
        Text("Персонажи — вымышленные дружелюбные помощники.", color = Muted, fontSize = 13.sp)
    }
}
